<?php
$errors = array(); // Initialize an error array.
$userName = "Guest";


// Check for a User name:
    $user_name = trim($_POST['user_name']);
    if (empty($user_name)) {
        $errors[] = 'You forgot to enter your username.';
    }


// Check for passwords and match:
$password1 = trim($_POST['password']);

if (empty($password1)) {
  
        $errors[] = 'You forgot to enter your password.';
    }



// Process the form if no errors
if (empty($errors)) {
    try {
        $hashed_passcode = password_hash($password1, PASSWORD_DEFAULT);

        require('Login_connect.php');

        $conn = get_db_conn();
        if (!$conn) {
            die("Database connection failed: " . mysqli_connect_error());
        }


        // Insert query using prepared statement

        $query = "SELECT users (UserName, Password, Role) 
                  VALUES (?, ?, ?)";

        $q = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($q, $query);
        mysqli_stmt_bind_param($q, 'sss',  $user_name, $hashed_passcode, $role);
        mysqli_stmt_execute($q);

        if($user && password_verify($password1, $user['password'])){
            echo "LOGIN SUCCESSFULL";
        } 
         else {
            $errorstring = "<p class='text-center col-sm-8' style='color:red'>
                System Error<br />You could not be registered due to a system error.<br>
                We apologize for any inconvenience.</p>";
            echo $errorstring;

            mysqli_close($conn);

            echo '<footer class="jumbotron text-center col-sm-12" style="padding-bottom:1px; padding-top:8px;">';
            include("footer.php");
            echo '</footer>';
            exit();
        }

    } catch (Exception $e) {
        print "The system is busy. Please try later.";
    } catch (Error $e) {
        print "The system is busy. Please try again later.";
    }

} else {
    // Display errors
    $errorstring = "<p class='text-center col-sm-8' style='color:red'>
        Error! The following error(s) occurred:<br>";

    foreach ($errors as $msg) {
        $errorstring .= " - $msg<br>\n";
    }

    $errorstring .= "Please try again.</p>";

    echo $errorstring;
}
?>
