<?php
/**
 * Gatekeeper. Call at the top of a view:
 *   require_login();                // any logged-in user
 *   require_login('admin');         // only admins
 *   require_login(['admin','user']); // any of these roles
 */
function require_login($allowed_roles = null) {
    session_start();
    if (!isset($_SESSION['uid']) || !is_int($_SESSION['uid'])) {
        $here = $_SERVER['REQUEST_URI'];
        if (strpos($here, "://") !== false || strpos($here, "\n") !== false) { $here = ''; }
        header('Location: login.php' . ($here ? ('?return=' . urlencode($here)) : ''));
        exit;
    }
    if ($allowed_roles !== null) {
        $allowed = is_array($allowed_roles) ? $allowed_roles : [$allowed_roles];
        $role = $_SESSION['role'] ?? '';
        if (!in_array($role, $allowed, true)) {
            http_response_code(403);
            echo 'Forbidden (requires role: ' . htmlspecialchars(implode(', ', $allowed)) . ')';
            exit;
        }
    }
}
