<?php  
function get_db_conn() {
    $hostname = "localhost";
    $username = "ecpi_user";
    $password = "Password1";
    $dbname = "sdc310_lab_lester";

    $conn = mysqli_connect($hostname, $username, $password, $dbname);
    if ($conn) {
        mysqli_set_charset($conn, 'utf8mb4');
    }
    return $conn; //mysqli|false
}