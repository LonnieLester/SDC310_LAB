<?php
require_once __DIR__ . '/../model/auth_db.php';

function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

/** Login page controller */
function login_page_data(): array {
    session_start();
    $user=""; $pass=""; $user_err=""; $pass_err=""; $msg="";

    $returnTo = isset($_GET['return']) ? $_GET['return'] : '';
    if ($returnTo && (strpos($returnTo, "://") !== false || strpos($returnTo, "\n") !== false)) {
        $returnTo = '';
    }

    if ($_SERVER['REQUEST_METHOD']==='POST') {
        $user = trim($_POST['username'] ?? '');
        $pass = (string)($_POST['password'] ?? '');

        if ($user === '') $user_err = 'Username is required.';
        if ($pass === '') $pass_err = 'Password is required.';

        if ($user_err === '' && $pass_err === '') {
            $row = find_user_by_username($user);
            if ($row && password_verify($pass, $row['password'])) {
                // Save identity + role in the session
                session_regenerate_id(true);
                $_SESSION['uid']   = (int)$row['userNo'];
                $_SESSION['uname'] = $row['username'];
                $_SESSION['role']  = $row['role'];   // <- admin/user
                $_SESSION['logged_in_at'] = time();

                header('Location: ' . ($returnTo ?: 'protected.php'));
                exit;
            } else {
                $msg = 'Invalid username or password.';
            }
        }
    }

    return compact('user','pass','user_err','pass_err','msg','returnTo');
}

/** Register page controller (only creates role = user) */
function register_page_data(): array {
    session_start();
    $user=""; $pass=""; $conf=""; $user_err=""; $pass_err=""; $conf_err=""; $msg="";

    if ($_SERVER['REQUEST_METHOD']==='POST') {
        $user = trim($_POST['username'] ?? '');
        $pass = (string)($_POST['password'] ?? '');
        $conf = (string)($_POST['confirm']  ?? '');

        if ($user === '') $user_err = 'Username is required.';
        if ($pass === '') $pass_err = 'Password is required.';
        elseif (strlen($pass) < 8) $pass_err = 'Password must be at least 8 characters.';
        if ($conf === '') $conf_err = 'Please confirm your password.';
        elseif ($pass !== '' && $conf !== $pass) $conf_err = 'Passwords do not match.';

        if ($user_err==='' && $pass_err==='' && $conf_err==='') {
            if (username_exists($user)) {
                $user_err = 'Username is already taken.';
            } else {
                $ok = create_user_account($user, $pass); // always role=user
                if ($ok) {
                    $msg = 'Registration successful. You can now ';
                    $user = $pass = $conf = '';
                } else {
                    $msg = 'Something went wrong creating the account.';
                }
            }
        }
    }

    return compact('user','pass','conf','user_err','pass_err','conf_err','msg');
}
