<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
require_once __DIR__ . '/database.php';

/** Look up a user by username. Returns assoc row or null. */
function find_user_by_username(string $username): ?array {
    $c = get_db_conn(); if (!$c) return null;

    $sql  = "SELECT userNo, username, role, password
               FROM users
              WHERE username = ?
              LIMIT 1";
    $stmt = mysqli_prepare($c, $sql);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);

    $res = mysqli_stmt_get_result($stmt);
    $row = ($res && mysqli_num_rows($res) === 1) ? mysqli_fetch_assoc($res) : null;

    if ($res) mysqli_free_result($res);
    mysqli_stmt_close($stmt);
    mysqli_close($c);
    return $row;
}

/** Does the username already exist? */
function username_exists(string $username): bool {
    $c = get_db_conn(); if (!$c) return false;

    $stmt = mysqli_prepare($c, "SELECT 1 FROM users WHERE username = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    $exists = mysqli_stmt_num_rows($stmt) > 0;

    mysqli_stmt_close($stmt);
    mysqli_close($c);
    return $exists;
}

/** Create a new account with role = 'user' (never admin via register). */
function create_user_account(string $username, string $plain_password): bool {
    $hash = password_hash($plain_password, PASSWORD_DEFAULT);
    $role = 'user'; // enforce user-only role for registration

    $c = get_db_conn(); if (!$c) return false;

    $stmt = mysqli_prepare($c, "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sss", $username, $hash, $role);
    $ok = mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);
    mysqli_close($c);
    return $ok;
}
