<?php
// View -> Controller
require_once('../controller/auth_controller.php');
$d = login_page_data(); // ['user','pass','user_err','pass_err','msg','returnTo']
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Login</title>
  <link rel="stylesheet" href="styles.css?v=1">
</head>
<body>
  <div class="card">
    <h2>Sign in</h2>
    <p class="sub">Use your account to continue</p>

    <?php if ($d['msg']) { ?>
      <div class="msg"><?php echo e($d['msg']); ?></div>
    <?php } ?>

    <form method="POST" action="login.php<?php echo $d['returnTo'] ? ('?return=' . urlencode($d['returnTo'])) : ''; ?>">
      <div class="row">
        <label for="username">Username</label>
        <input id="username" name="username" type="text" value="<?php echo e($d['user']); ?>" autocomplete="username" />
        <?php if ($d['user_err']) { ?><span class="err"><?php echo e($d['user_err']); ?></span><?php } ?>
      </div>

      <div class="row">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" autocomplete="current-password" />
        <?php if ($d['pass_err']) { ?><span class="err"><?php echo e($d['pass_err']); ?></span><?php } ?>
      </div>

      <button type="submit">Log In</button>
    </form>

    <div class="links">No account? <a href="register.php">Register</a></div>
  </div>
</body>
</html>
