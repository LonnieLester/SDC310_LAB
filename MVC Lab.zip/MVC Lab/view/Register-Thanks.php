<!-- Header Section --> 
<header class="jumbotron text-center row" 
        style="margin-bottom:2px; background:linear-gradient(white, #0073e6); padding:20px;"> 
  <?php include('header.php'); ?> 
</header> 
 
<!-- Body Section --> 
<div class="row" style="padding-left: 0px;"> 
 
  <!-- Left-side Column Menu Section --> 
  <nav class="col-sm-2"> 
    <ul class="nav nav-pills flex-column"> 
      <?php include('nav.php'); ?> 
    </ul> 
  </nav> 
 
  <!-- Center Column Content Section -->
    <div class="col-sm-8">
     <h2 class="text-center">Registration Successful!!! Login Below</h2>
      <p><a href="login.php"> LOGIN</a></p>
  </div>
 
  <!-- Right-side Column Content Section --> 
  <?php 
  if (!isset($errorstring)) { 
    echo '<aside class="col-sm-2">'; 
    include('info-col.php'); 
    echo '</aside>'; 
  } 
  ?> 
</div> <!-- End of row --> 
 
<!-- Footer Section --> 
<?php 
if (!isset($errorstring)) { 
  echo '<footer class="jumbotron text-center row" 
               style="padding-bottom:1px; padding-top:8px;">'; 
} else { 
  echo '<footer class="jumbotron text-center col-sm-12" 
               style="padding-bottom:1px; padding-top:8px;">'; 
} 
include('footer.php'); 
echo '</footer>'; 
?> 
 

 