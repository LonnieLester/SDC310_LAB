<li class="nav-item">
          <a class="nav-link active" href="index.php">Home</a>
  </li>
  <li class="nav-item">
          <a class="nav-link" href="page-2.php">Cart</a>
   <li>
   <li class="nav-item">
          <a class="nav-link" href="login.php">Login</a>
   </li>
   <li class="nav-item">
          <a class="nav-link" href="products.php">Products</a>
   </li>
   <li class="nav-item">
          <a class="nav-link" href="page-5.php">Page 5</a>