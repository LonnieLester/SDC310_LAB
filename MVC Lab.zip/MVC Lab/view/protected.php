<?php
require_once __DIR__ . '/../controller/require_login.php';
require_login();

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Protected Area</title>
</head>
<body>
  <h2>Welcome, <?php echo htmlspecialchars($_SESSION['uname'] ?? '', ENT_QUOTES, 'UTF-8'); ?>!</h2>
  <p>This page is protected. Only logged-in users can see it.</p>
  <p><a href="logout.php">Log out</a></p>
</body>
</html>
