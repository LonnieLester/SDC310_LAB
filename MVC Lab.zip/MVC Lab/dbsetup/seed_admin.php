<?php
// seed_admin.php — create an initial admin user (run once, then delete/secure)
require __DIR__ . "/db_connect.php";

$username = "admin1";
$plain    = "AdminPass123";  // change before running in class if desired

$hash = password_hash($plain, PASSWORD_DEFAULT);
$role = "admin";

$stmt = mysqli_prepare($conn, "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)");
mysqli_stmt_bind_param($stmt, "sss", $username, $hash, $role);
$ok = mysqli_stmt_execute($stmt);
$rows = mysqli_stmt_affected_rows($stmt);
mysqli_stmt_close($stmt);
mysqli_close($conn);

header('Content-Type: text/plain');
if ($ok && $rows > 0) {
    echo "Seeded admin user.\nUsername: {$username}\nPassword: {$plain}\nRole: {$role}\n";
} else {
    echo "No rows inserted. The username may already exist.\n";
}
